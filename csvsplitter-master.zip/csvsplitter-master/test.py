import converter

converter.convert_to_utf8("splitted/%s.csv" % 'zongheng')