# csvsplitter
large csv file splitter by column, write by python.
similar with "group by", this code will group by rows into splitted files, based on a specified column

=======how to use========

python main.py {csv file path} {column index}

for example: python main.py novels.csv 33
